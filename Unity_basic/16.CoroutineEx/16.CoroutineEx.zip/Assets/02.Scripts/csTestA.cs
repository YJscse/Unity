﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class csTestA : MonoBehaviour {

	// Use this for initialization
	void Start () {

        //Debug.Log(gameObject.GetInstanceID());
        Debug.Log(gameObject.name + " : 1");
        Debug.Log(gameObject.name + " : 2");
        Debug.Log(gameObject.name + " : 3");
        
    }
	
	
}
