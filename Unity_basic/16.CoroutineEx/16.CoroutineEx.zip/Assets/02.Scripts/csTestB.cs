﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class csTestB : MonoBehaviour {

	// Use this for initialization
	IEnumerator Start ()
    {                              // yield(양보하다)를 쓰려면 void를 IEnumerator로 바꿔야한다
        Debug.Log(gameObject.name + " : 1");
        yield return null;
        Debug.Log(gameObject.name + " : 2");
        Debug.Log(gameObject.name + " : 3");

    }

 
}
