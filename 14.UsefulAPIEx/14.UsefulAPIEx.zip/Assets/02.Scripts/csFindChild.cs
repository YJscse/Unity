﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class csFindChild : MonoBehaviour {

    public Transform[] myChilds;

	// Use this for initialization
	void Start () {

        int randomSeedS;
        randomSeedS = (int)System.DateTime.Now.Ticks;
        Random.seed = randomSeedS;

        myChilds = GameObject.Find("SpawnPoint").GetComponentsInChildren<Transform>();

        int idx = Random.Range(1, myChilds.Length);

        Debug.Log("SpawnPoint.Length : " + myChilds.Length);
        Debug.Log("Rnadom.Range : " + idx);

        for(int i = 0; i < myChilds.Length; i++)
        {
            Debug.Log(myChilds[i].gameObject.name);
        }
	}
	

}
