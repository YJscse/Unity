﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class csGameManager2 : MonoBehaviour {

    static csGameManager2 _instance = null;
    public static csGameManager2 Instance()
    {
        return _instance;
    }

    void Awake()
    {
        if (_instance == null)
        {
            _instance = this;
            DontDestroyOnLoad(this.gameObject);
            Debug.Log("aaaa");
        }
        else
        {
            Debug.Log("bbbb");
            if (this != _instance)
            {
                Destroy(this.gameObject);
                Debug.Log("cccc");
            }
            else
            {
                Debug.Log("dddd");
            }
        }
    }

    public void doSomething()
    {
        // Do Somethig ...
    }
}
