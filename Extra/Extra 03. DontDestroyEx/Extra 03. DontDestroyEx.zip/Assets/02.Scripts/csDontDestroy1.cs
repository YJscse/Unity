﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class csDontDestroy1 : MonoBehaviour {

    void Awake()
    {
        // 새로운 씬을 로드 할 때 오브젝트가 사라지지 않도록 해주는 함수
        // 유니티에서 싱글톤 대신 사용할 수 있다.
        DontDestroyOnLoad(this.gameObject);
    }
}
