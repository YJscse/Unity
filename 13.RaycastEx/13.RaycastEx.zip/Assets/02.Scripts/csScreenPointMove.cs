﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class csScreenPointMove : MonoBehaviour {
	
	// Update is called once per frame
	void Update () {
		
        if(Input.GetButtonUp("Fire1"))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            if(Physics.Raycast(ray, out hit))
            {
                Vector3 newPos = new Vector3(hit.point.x,
                                            transform.position.y,
                                            hit.point.z);
                transform.position = newPos;
            }
        }
	}
}
