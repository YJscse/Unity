﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;

public class CicularMenu : MonoBehaviour
{
	public List<MenuButton> buttons = new List<MenuButton> ();
	private Vector2 Mousepositon;
	private Vector2 fromVector2M = new Vector2 (0.5f, 1.0f); // 0.5 1.0
	private Vector2 centercirlce = new Vector2 (0.5f, 0.5f); // 0.5 0.5
	private Vector2 toVector2M;

	public int menuItems;
	public int CurMenuItem;
	private int OldMenuItem;

//	public BuildSystem buildsys;

	void Start()
	{
		menuItems = buttons.Count;
		foreach (MenuButton button in buttons)
		{
			button.sceneimage.color = button.NormalColor;
		}
		CurMenuItem = 0;
		OldMenuItem = 0;
	}

	void Update()
	{
		GetCurrentMenuItem ();
		if (Input.GetButtonDown ("Fire1")) {
			ButtonAction ();
		}
	}

	public void GetCurrentMenuItem()
	{
		Mousepositon = new Vector2 (Input.mousePosition.x, Input.mousePosition.y);
		//                                              x                      y
		toVector2M = new Vector2 (Mousepositon.x / Screen.width, Mousepositon.y / Screen.height);
		//                                     x                              y
		float angle = (Mathf.Atan2 (fromVector2M.y - centercirlce.y, fromVector2M.x - centercirlce.x) - Mathf.Atan2 (toVector2M.y - centercirlce.y,  toVector2M.x - centercirlce.x)) * Mathf.Rad2Deg;
		//                                       y                y               x                x                 toVector2M.y - centercirlce.y,  toVector2M.x - centercirlce.x                                          
		if (angle < 0)
			angle += 360;

		CurMenuItem = (int) angle / (360 / menuItems);

		if(CurMenuItem != OldMenuItem)
		{
			buttons[OldMenuItem].sceneimage.color = buttons[OldMenuItem].NormalColor;
			OldMenuItem = CurMenuItem;
			buttons[CurMenuItem].sceneimage.color = buttons[CurMenuItem].HighlightedColor;
		}

	}

	public void ButtonAction()
	{
		buttons [CurMenuItem].sceneimage.color = buttons [CurMenuItem].PressedColor;
		if (CurMenuItem == 0)
			Debug.Log ("0 selected");
		
//		buildsys.ChangeCurrentBuilding (CurMenuItem);
//		buildsys.TurnOffTheMenu ();
	}
}

[System.Serializable]
public class MenuButton
{
	public string name;
	public Image sceneimage;
	public Color NormalColor = Color.white;
	public Color HighlightedColor = Color.grey;
	public Color PressedColor = Color.gray;
}
