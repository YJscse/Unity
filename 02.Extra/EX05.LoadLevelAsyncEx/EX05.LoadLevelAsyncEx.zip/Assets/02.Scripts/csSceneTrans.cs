﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class csSceneTrans : MonoBehaviour {

    public void SceneTransTo2()
    {
        //Application.LoadLevel ("02-Loading");
        SceneManager.LoadScene("02-Loading");
    }

    public void SceneTransTo1()
    {
        //Application.LoadLevel ("01-Loading");
        SceneManager.LoadScene("01-First");
    }
}
