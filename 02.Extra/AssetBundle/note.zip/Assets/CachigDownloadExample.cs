﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class CachigDownloadExample : MonoBehaviour {

    public string BundleURL;

    public int version;

	// Use this for initialization
	void Start () {
        StartCoroutine(DownloadAndCache());	
	}
	
	IEnumerator DownloadAndCache()
    {
        while (!Caching.ready)
            yield return null;

        using (WWW www = WWW.LoadFromCacheOrDownload(BundleURL, version))
        {
            yield return www;
            
            if(www.error != null)
            {
                throw new System.Exception("WWW 다운로드에 에러가 생겼습니다. :" + www.error);
            }
        }
    }
}
