﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class LoadAssetBundleExample : MonoBehaviour {

    public string BundleURL;

    public int version;

    // Use this for initialization
    void Start()
    {
        StartCoroutine(LoadaAssetBundle());
    }

    IEnumerator LoadaAssetBundle()
    {
        while (!Caching.ready)
            yield return null;

        using (WWW www = WWW.LoadFromCacheOrDownload(BundleURL, version))
        {
            yield return www;

            if (www.error != null)
            {
                throw new System.Exception("WWW 다운로드에 에러가 생겼습니다. :" + www.error);
            }

            AssetBundle bundle = www.assetBundle;
            AssetBundleRequest request = bundle.LoadAssetAsync<GameObject>("Cube");

            yield return request;

            GameObject cube = Instantiate(request.asset) as GameObject;
            cube.transform.position = new Vector3(1, 1, 1);

            bundle.Unload(false);
            www.Dispose();
        }
    }
}
