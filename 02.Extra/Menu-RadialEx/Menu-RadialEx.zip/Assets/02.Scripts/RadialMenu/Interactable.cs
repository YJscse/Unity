﻿using UnityEngine;
using System.Collections;

// Radial Menu가 필요한 객체에 이 스크립트를 추가한다.
public class Interactable : MonoBehaviour {

	// 메뉴 버튼 색, 그림, 타이틀
	[System.Serializable]
	public class Action {
		public Color color;
		public Sprite sprite;
		public string title;
	}

	// 팝업메뉴 옵션 (갯수, 위 Action 속성 사용)
	public Action[] options;

	// Radial Menu에 보여질 메뉴명 (없으면 객체명 사용)
	public string title;

	void Start () {
		if (title == "" || title == null) {
			title = gameObject.name;
		}
	}

	void OnMouseDown () {
		// Radial Menu Popup
		RadialMenuSpawner.Instance().SpawnMenu(this);
	}

}
