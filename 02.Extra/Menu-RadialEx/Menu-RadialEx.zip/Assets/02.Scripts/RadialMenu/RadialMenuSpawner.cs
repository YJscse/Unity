﻿using UnityEngine;
using System.Collections;

// 이 스립트는 Canvas에 추가
public class RadialMenuSpawner : MonoBehaviour {

	static RadialMenuSpawner _instance = null;
	public RadialMenu menuPrefab;			// prefab menu to instantiate

	public static RadialMenuSpawner Instance()
	{
		return _instance;
	}

	void Awake () {
		if (_instance == null)
			_instance = this;
	}

	// 마우스 클릭한 위치에서 Radial Menu 초기화
	public void SpawnMenu(Interactable obj){
		RadialMenu newMenu = Instantiate(menuPrefab) as RadialMenu;
		newMenu.transform.SetParent (transform, false);
		newMenu.transform.position = Input.mousePosition;
//		newMenu.label.text = obj.title.ToUpper ();
		newMenu.label.text = obj.title;
		newMenu.SpawnButtons(obj);
	}

}
