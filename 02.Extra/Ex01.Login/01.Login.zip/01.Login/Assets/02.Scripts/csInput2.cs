﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class csInput2 : MonoBehaviour {
    Text txt;
    
    void Start () {
        txt = GameObject.Find("txtCenter").GetComponent<Text>();
    }
    
    void Update () {
        txt.text = csInput.str;
    }
}
