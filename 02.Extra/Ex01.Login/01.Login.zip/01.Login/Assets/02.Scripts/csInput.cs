﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class csInput : MonoBehaviour {
    
    InputField input1;
    public static string str;
    
    void Start()
    {
        input1 = GameObject.Find("InputField1").GetComponent<InputField>();
    }
    
    public void ChangeValue()
    {
        if(input1.text.Length < 4)
        {
            if(EditorUtility.DisplayDialog("알림", "입력은 4자 이상 해주시기 바랍니다.", "확인"))
            {
                input1.Select();
            }
        }
        else
        {
            str = input1.text;
            SceneManager.LoadScene("02-Main");
        }
        Debug.Log("InputField1: " + input1.text);
    }
}
