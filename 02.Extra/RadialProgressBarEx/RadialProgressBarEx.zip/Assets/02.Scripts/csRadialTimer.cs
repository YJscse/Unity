﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class csRadialTimer : MonoBehaviour {
	Image fillImg;
	float timeAmt = 10;
	float time;
	public Text timeText;  

	void Start () 
	{
		fillImg = this.GetComponent<Image>();
		time = timeAmt;
	}

	void Update () 
	{
		if (time > 0)
		{
			time -= Time.deltaTime;
			fillImg.fillAmount = time / timeAmt; 
			timeText.text = "Time : " + time.ToString("F");  
		}
	}
}