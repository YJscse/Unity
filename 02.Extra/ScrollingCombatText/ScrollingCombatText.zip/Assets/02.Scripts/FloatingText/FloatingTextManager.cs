﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FloatingTextManager : MonoBehaviour {

	static FloatingTextManager _instance = null;

	public static FloatingTextManager Instance()
	{
		return _instance;
	}

	void Start () 
	{
		if (_instance == null)
			_instance = this;
	}

	public GameObject canvas;
	public csFloatingText popupText;

	public void CreatingFloatingText (string text, Transform location)
	{
		csFloatingText instance = Instantiate (popupText);

		Vector2 screenPosition = Camera.main.WorldToScreenPoint (
			new Vector2(location.position.x + Random.Range(-0.5f, 0.5f),
				        location.position.y + Random.Range(-0.5f, 0.5f)));

		instance.transform.SetParent (canvas.transform, false);
		instance.transform.position = screenPosition;
		instance.SetText (text);
        Debug.Log("aa");
	}
}
