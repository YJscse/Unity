﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class csEnemy : MonoBehaviour {

	float speed = 2.0f;
	int dir = 1;

	void Update () 
	{
		if (transform.position.x > 3) {
			dir = -1;
		}
		if (transform.position.x < -3) {
			dir = 1;
		}

		transform.Translate(Vector3.right * speed * Time.deltaTime * dir);
	}

	void OnMouseDown () {
		TakeDamage(Random.Range(1, 100));		
	}

	public virtual void TakeDamage (int amount) 
	{
		FloatingTextManager.Instance().CreatingFloatingText (amount.ToString(), transform);
	}
}
