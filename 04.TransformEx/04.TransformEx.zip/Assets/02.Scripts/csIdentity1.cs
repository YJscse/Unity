﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class csIdentity1 : MonoBehaviour {

    public float rotSpeed = 120.0f;

	// Update is called once per frame
	void Update () {

        // 씬 뷰의 큐브를 선택하고 게임 뷰에서 화면을 클릭해
        // 씬 뷰에 있는 큐브의 기즈모를 통해 확인

        // 회전
        float amtRot = rotSpeed * Time.deltaTime;
        float ang = Input.GetAxis("Horizontal");
        transform.Rotate(Vector3.up * ang * amtRot);

        // 정력
        // 월드 좌표 또는 부모 축에 완벽히 정렬
        if (Input.GetButtonDown("Fire1"))  // 마우스 왼쪽 클릭이나, 컨트롤키 
        {
            //transform.rotation = Quaternion.identity;         // 월드에 정렬
            transform.localRotation = Quaternion.identity;      // 로컬(부모)에 정렬
        }
    }
}
