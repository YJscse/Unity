﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class csThrow2 : MonoBehaviour {

    float power = 800.0f;
    Vector3 velocity = new Vector3(0.5f, 0.5f, 0.0f);

    void FixedUpdate()
    {

        if (Input.GetButtonDown("Fire1")) // FixedUpdate <- 일정하게 시간을 계산 하기때문에 deltaTime 을 곱하면 안된다 곱하면 오류다 논리적 오류
        {
            GetComponent<Rigidbody>().velocity = new Vector3(7, 7, 0);  
        }

    }
}
