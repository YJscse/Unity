﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class csJump1 : MonoBehaviour {

    void FixedUpdate()
    {

        if (Input.GetButtonDown("Jump")) // FixedUpdate <- 일정하게 시간을 계산 하기때문에 deltaTime 을 곱하면 안된다 곱하면 오류다 논리적 오류
        {
            GetComponent<Rigidbody>().velocity = new Vector3(0, 10, 0); 
        }

    }
}
