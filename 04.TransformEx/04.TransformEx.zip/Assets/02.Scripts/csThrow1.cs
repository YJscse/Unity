﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class csThrow1 : MonoBehaviour {

    float power = 800.0f;
    Vector3 velocity = new Vector3(0.5f, 0.5f, 0.0f);

    // If you want to apply a force over several frames
    // you should apply it inside FixedUpdate instead of Update
	void FixedUpdate () {

        if (Input.GetButtonDown("Fire1")) // FixedUpdate <- 일정하게 시간을 계산 하기때문에 deltaTime 을 곱하면 안된다 곱하면 오류다 논리적 오류
        {
            velocity = velocity * power;

            GetComponent<Rigidbody>().AddForce(velocity);  // AddForce ← 가만있는 야구공을 야구배트로 치는것같이 힘이 작용
        }
		
	}
}
