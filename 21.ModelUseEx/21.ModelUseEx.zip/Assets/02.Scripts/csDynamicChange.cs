﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class csDynamicChange : MonoBehaviour {

    public Material[] _M_Hair1;
    public Material[] _M_Top1;
    public Material[] _M_Pants1;
    public Material[] _M_Shoes1;

    public GameObject _Hair1;
    public GameObject _Top1;
    public GameObject _Pants1;
    public GameObject _Shoes1;

    int nTop1 = 0;
    int nHair1 = 0;
    int nPants1 = 0;
    int nShoes1 = 0;

    // -------------------------------------------------------------------

    public void ChangeHair1()
    {
        nHair1++;

        if (nHair1 > _M_Hair1.Length - 1)
        {
            nHair1 = 0;
        }

        CharMaterialSet(_Hair1, _M_Hair1[nHair1]);
    }

    public void ChangeTop1()
    {
        nTop1++;

        if(nTop1 > _M_Top1.Length - 1)
        {
            nTop1 = 0;
        }

        CharMaterialSet(_Top1, _M_Top1[nTop1]);
    }


    // ----------------------------------------------------

    public void ChangePants1()
    {
        nPants1++;

        if (nPants1 > _M_Pants1.Length - 1)
        {
            nPants1 = 0;
        }

        CharMaterialSet(_Pants1, _M_Pants1[nPants1]);
    }

    public void ChangeShoes1()
    {
        nShoes1++;

        if (nShoes1 > _M_Shoes1.Length - 1)
        {
            nShoes1 = 0;
        }

        CharMaterialSet(_Shoes1, _M_Shoes1[nShoes1]);
    }

    // --------------------------------

    void CharMaterialSet(GameObject obj, Material mat)
    {
        obj.GetComponent<Renderer>().material = mat;
    }
}
