﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class csResourcesLoad : MonoBehaviour {

    string[] _M_Hair1 = {
       "Images/female_hair-1_brown",
       "Images/female_hair-1_red",
       "Images/female_hair-1_yellow"};

    string[] _M_Top1 = {
        "Images/female_top-1_green",
        "Images/female_top-1_blue",
        "Images/female_top-1_pink"};

    string[] _M_Pants1 = {
        "Images/female_pants-1_dark",
        "Images/female_pants-1_blue",
        "Images/female_pants-1_green"};

    string[] _M_Shoes1 = {
        "Images/female_shoes-1_green",
        "Images/female_shoes-1_blue",
        "Images/female_shoes-1_yellow"};

    public GameObject _Hair1;
    public GameObject _Top1;
    public GameObject _Pants1;
    public GameObject _Shoes1;

    int nTop1 = 0;
    int nHair1 = 0;
    int nPants1 = 0;
    int nShoes1 = 0;

    // ------------------------

    public void ChangeHair1()
    {
        nHair1++;

        if (nHair1 > _M_Hair1.Length - 1)
        {
            nHair1 = 0;
        }

        CharMaterialSet(_Hair1, _M_Hair1[nHair1]);
    }

    public void ChangeTop1()
    {
        nTop1++;

        if (nTop1 > _M_Top1.Length - 1)
        {
            nTop1 = 0;
        }

        CharMaterialSet(_Top1, _M_Top1[nTop1]);
    }


    // ----------------------------------------------------

    public void ChangePants1()
    {
        nPants1++;

        if (nPants1 > _M_Pants1.Length - 1)
        {
            nPants1 = 0;
        }

        CharMaterialSet(_Pants1, _M_Pants1[nPants1]);
    }

    public void ChangeShoes1()
    {
        nShoes1++;

        if (nShoes1 > _M_Shoes1.Length - 1)
        {
            nShoes1 = 0;
        }

        CharMaterialSet(_Shoes1, _M_Shoes1[nShoes1]);
    }

    // --------------------------------

    void CharMaterialSet(GameObject obj, string mat)
    {
        obj.GetComponent<Renderer>().material.mainTexture = Resources.Load(mat) as Texture;
    }

}
