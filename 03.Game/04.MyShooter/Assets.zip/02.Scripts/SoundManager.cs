﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundManager : MonoBehaviour {

    public static SoundManager instance;

    public AudioClip sndExplosion;
    public AudioClip sndFire;

    AudioSource myAudio;

    void Awake()
    {
        if(SoundManager.instance == null)
        {
            SoundManager.instance = this;
        }
    }

    // Use this for initialization
    void Start () {
        myAudio = GetComponent<AudioSource>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void PlayeSound()
    {
        myAudio.PlayOneShot(sndExplosion);
    }
    public void effectSound()
    {
        myAudio.PlayOneShot(sndFire);
    }
}
