﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour {

    public static GameManager instance;
    public bool isDead = false;

    int score = 0;
    public Text scoreText;
    public GameObject readyText;
    public Text overText;
    public GUISkin skin;

    
    void Awake()
    {     
        if(GameManager.instance == null)
        {
            GameManager.instance = this;
        }
    }

    // Use this for initialization
    void Start () {
        Invoke("StartGame", 3.0f);
        readyText.SetActive(false);
        StartCoroutine(showReady());
	}

    void StartGame()
    {
        csPlayer.canShoot = true;
        csEnemy.canShoot = true;
        csEnemyM.canShoot = true;
        csEnemyB.canShoot = true;
        csSpawnManager.isSpawn = true;
    }

    public void AddScore(int score)
    {
        this.score += score;
        scoreText.text = "Score : " + this.score;
    }

    public void over()
    {
        overText.text = "Game Over";
        csPlayer.canShoot = false;
        csSpawnManager.isSpawn = false;
        isDead = true;
    }

    void OnGUI()
    {
        GUI.skin = skin;

        int sw = Screen.width;
        int sh = Screen.height;


        Rect rect = new Rect(0, 0.6f * sh, sw, 0.4f * sh);
        if (isDead)
        {
            GUI.Label(rect, "CONTINUE?", "Game");

            if (GUI.Button(new Rect(sw * 0.3f, 0.7f * sh, sw * 0.15f, 0.25f * sh), "Yes", "Game2"))
            {
                SceneManager.LoadScene("Game");
            }

            if (GUI.Button(new Rect(sw * 0.6f, 0.7f * sh, sw * 0.15f, 0.25f * sh), "No", "Game2"))
            {
                SceneManager.LoadScene("Intro");
            }

        }
    }

    IEnumerator showReady()
    {

        int count = 0;
        while (count < 3)
        {
            readyText.SetActive(true);
            yield return new WaitForSeconds(0.5f);

            readyText.SetActive(false);
            yield return new WaitForSeconds(0.5f);

            count++;
        }

    }

 
}
