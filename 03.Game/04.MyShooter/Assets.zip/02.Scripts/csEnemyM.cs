﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class csEnemyM : MonoBehaviour {

    public float moveSpeed = 0.5f;
    public GameObject explosionPrefab;
    public GameObject laserPrefab;

    int killScore = 400;
    int hp = 3;

    public static bool canShoot = false;

    float shootDelay = 2.0f;
    float shootTimer = 0.0f;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        MoveEnemy();
        ShootLaser();
    }

    void MoveEnemy()
    {
        float yMove = moveSpeed * Time.deltaTime;
        float xMove = moveSpeed * Time.deltaTime;
        transform.Translate(xMove, -yMove, 0);     
        
        if(transform.position.x > 1)
        {
            Destroy(gameObject, 1.0f);
        }
    }

    void OnTriggerEnter2D(Collider2D col)
    {
        if (col.gameObject.tag == "Player")
        {
            Instantiate(explosionPrefab, transform.position, Quaternion.identity);
            SoundManager.instance.PlayeSound();
            GameManager.instance.over();

            Destroy(col.gameObject);
            Destroy(gameObject);

        }

        else if (col.gameObject.tag == "Laser")
        {
            Instantiate(explosionPrefab, transform.position, Quaternion.identity);
            SoundManager.instance.PlayeSound();

            hp--;
            if (hp == 0)
            {
                GameManager.instance.AddScore(killScore); 
                Destroy(gameObject);
            }
            Destroy(col.gameObject);
        }
    }

    void ShootLaser()
    {
        if (canShoot == true)
        {
            if (shootTimer > shootDelay)
            {
                Instantiate(laserPrefab, transform.position, Quaternion.identity);
                shootTimer = 0.0f;
            }

            shootTimer += Time.deltaTime;
        }
    }
}
