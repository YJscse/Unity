﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class csEnemy : MonoBehaviour {

    public float moveSpeed = 0.05f;
    public GameObject explosionPrefab;
    public GameObject laserPrefab;

    int killScore = 100;

    public static bool canShoot = false;

    float shootDelay = 2.0f;
    float shootTimer = 0.0f;

    // Use this for initialization
    void Start () {
		
	}

    // Update is called once per frame
    void Update()
    {
        MoveEnemy();
        ShootLaser();
        if (transform.position.y < -1.2f)
        {
            Destroy(gameObject);
        }
    }

    void MoveEnemy()
    {
        float yMove = moveSpeed * Time.deltaTime;
        transform.Translate(0, -yMove, 0);
    }

    void OnTriggerEnter2D(Collider2D col)
    {
        if(col.gameObject.tag == "Player")
        {          
            Instantiate(explosionPrefab, transform.position, Quaternion.identity);
            SoundManager.instance.PlayeSound();
            GameManager.instance.over();

            Destroy(col.gameObject);
            Destroy(gameObject);
           
        }

        else if(col.gameObject.tag == "Laser")
        {
            Instantiate(explosionPrefab, transform.position, Quaternion.identity);
            SoundManager.instance.PlayeSound();
            GameManager.instance.AddScore(killScore);

            Destroy(col.gameObject);
            Destroy(gameObject);
        }
    }

    void ShootLaser()
    {
        if (canShoot == true)
        {
            if (shootTimer > shootDelay)
            {
                Instantiate(laserPrefab, transform.position, Quaternion.identity);
                shootTimer = 0.0f;
            }

            shootTimer += Time.deltaTime;
        }
    }

}
