﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class csEnemyB : MonoBehaviour {

    public float moveSpeed = 0.4f;
    public GameObject explosionPrefab;
    public GameObject laserPrefab;

    int killScore = 700;
    int hp = 5;

    public static bool canShoot = false;

    float shootDelay = 2.5f;
    float shootTimer = 0.0f;
    float delay = 0.0f;
    float std;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        MoveEnemy();
        ShootLaser();

        if (transform.position.y < -1.2f)
        {
            Destroy(gameObject);
        }
    }

    void MoveEnemy()
    {
        float yMove = moveSpeed * Time.deltaTime;
        transform.Translate(0, -yMove, 0);

        delay += Time.deltaTime;
        std = Random.Range(1.0f, 2.0f);
        if (delay > std)
        {
            StartCoroutine(bigMoving());
        }
    }

    void OnTriggerEnter2D(Collider2D col)
    {
        if (col.gameObject.tag == "Player")
        {
            Instantiate(explosionPrefab, transform.position, Quaternion.identity);
            SoundManager.instance.PlayeSound();
            GameManager.instance.over();

            Destroy(col.gameObject);
            Destroy(gameObject);

        }

        else if (col.gameObject.tag == "Laser")
        {
            Instantiate(explosionPrefab, transform.position, Quaternion.identity);
            SoundManager.instance.PlayeSound();
      
            hp--;
            if (hp == 0)
            {
                GameManager.instance.AddScore(killScore);
                Destroy(gameObject);
            }
            Destroy(col.gameObject);
        }
    }

    void ShootLaser()
    {
        if (canShoot == true)
        {
            if (shootTimer > shootDelay)
            {
                Instantiate(laserPrefab, transform.position, Quaternion.identity);
                shootTimer = 0.0f;
            }

            shootTimer += Time.deltaTime;
        }
    }

    IEnumerator bigMoving()
    {
        moveSpeed = 0.0f;
        float yMove = moveSpeed * Time.deltaTime;
        
        float rand = Random.Range(0.5f, 1.5f);

       // transform.Translate(0, yMove, 0);
        yield return new WaitForSeconds(rand);
        moveSpeed = 0.4f;
        transform.Translate(0, -yMove, 0);
    }
}
