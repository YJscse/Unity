﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneScript : MonoBehaviour {

    public GUISkin skin;
	
	// Update is called once per frame
	void Update () {
		if(Input.GetButtonDown("Fire1"))
        {
            StartCoroutine(sceneTrans());
        }
	}

    void OnGUI()
    {
        GUI.skin = skin;

        int sw = Screen.width;
        int sh = Screen.height;

        GUI.Label(new Rect(0, 0.6f * sh, sw, 0.4f * sh), "PRESS SPACE TO START", "Title");
    }

    IEnumerator sceneTrans()
    {
        yield return new WaitForSeconds(0.5f);
        SceneManager.LoadScene("Game");
    }
}
