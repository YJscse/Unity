﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class csPlayer : MonoBehaviour {

    public float moveSpeed = 0.5f;

    public GameObject laserPrefab;
    public GameObject explosionPrefab;

    public static bool canShoot = false;

    float shootDelay = 1.0f;
    float shootTimer = 0.0f;

    // Update is called once per frame
    void Update () {
        MovePlayer();
        ShootLaser();
	}

    void MovePlayer()
    {
        float moveX = moveSpeed * Time.deltaTime * Input.GetAxis("Horizontal");
        transform.Translate(moveX, 0,0);

        Vector3 viewPos = Camera.main.WorldToViewportPoint(transform.position);
        viewPos.x = Mathf.Clamp01(viewPos.x);
        Vector3 worldPos = Camera.main.ViewportToWorldPoint(viewPos);

        transform.position = worldPos;
    }

    void ShootLaser()
    {
        if(canShoot == true)
        {
            if(shootTimer > shootDelay)
            {
                Instantiate(laserPrefab, transform.position, Quaternion.identity);
                shootTimer = 0.0f;
                SoundManager.instance.effectSound();
            }

            shootTimer += Time.deltaTime;
        }
    }

    void OnTriggerEnter2D(Collider2D col)
    {
        if (col.gameObject.tag == "EnemyLaser")
        {
            Instantiate(explosionPrefab, transform.position, Quaternion.identity);
            SoundManager.instance.PlayeSound();
            GameManager.instance.over();

            Destroy(col.gameObject);
            Destroy(gameObject);
            Debug.Log("enemyLaser");
        }
    }
}
