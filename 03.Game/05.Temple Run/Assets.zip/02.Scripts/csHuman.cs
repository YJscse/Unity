﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class csHuman : MonoBehaviour {

    public GUISkin skin;

    GameObject manager;

    int speedForward = 12;
    int speedSide = 6;
    int jumpPower = 250;

    bool canJump = true;
    bool canTurn = false;
    bool canLeft = true;
    bool canRight = true;
    bool isGround = true;
    bool isDead = false;

    float dirX = 0;
    float score = 0;

    Vector3 touchStart;

	// Use this for initialization
	void Start () {
        Screen.orientation = ScreenOrientation.Portrait;
        Screen.sleepTimeout = SleepTimeout.NeverSleep;

        manager = GameObject.Find("BridgeManager");
	}

    // ===============
    // 게임루프
    // ===============
	
	// Update is called once per frame
	void Update () {
        if (isDead)
            return;
        if(Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }

        CheckMove();        
        MoveHuman();

        score += Time.deltaTime * 1000;     // 득점 처리
	}


    // ===============
    // 이동 가능한 상태인지 조사
    // ===============
    void CheckMove()
    {
        RaycastHit hit;

        // down     - 주인공이 다리 위에 있는가?
        isGround = true;
        if(Physics.Raycast(transform.position, Vector3.down, out hit, 2f))
        {
            if(hit.transform.tag == "BRIDGE")
            {
                isGround = true;
            }
        }

        // left     - 왼쪽으로 이동 가능한가?
        canLeft = true;
        if (Physics.Raycast(transform.position, Vector3.left, out hit, 0.7f))
        {
            if (hit.transform.tag == "GUARD")
            {
                canLeft = false;
            }
        }

        // right     - 오른쪽으로 이동 가능한가?
        canRight = true;
        if (Physics.Raycast(transform.position, transform.right, out hit, 0.7f))
        {
            if (hit.transform.tag == "GUARD")
            {
                canRight = false;
            }
        }
    }

    // ==================
    // 주인공 이동
    // ==================
    void MoveHuman()
    {
        dirX = 0;       // 좌우 이동 방향 (왼쪽: -1, 오른쪽 : 1)

        // Mobile
        if(Application.platform == RuntimePlatform.Android ||
           Application.platform == RuntimePlatform.IPhonePlayer)
        {
            CheckMobile();
        }
        else
        {
            CheckKeyboard();
        }

        // 이동 방향 설정
        Vector3 moveDir = new Vector3(dirX * speedSide, 0, speedForward);
        transform.Translate(moveDir * Time.smoothDeltaTime);
    }

    // ==============
    // 모바일 기기 조사
    // ==============
    void CheckMobile()
    {
        // 중력가속도 센서 읽기
        float x = Input.acceleration.x;

        // 좌우 이동 속도를 줄인다.
        if (x < -0.2f && canLeft && isGround)
            dirX = -0.6f;

        if (x > 0.2f && canRight && isGround)
            dirX = 0.6f;

        // 모든 Touch에 대해서 조사
        foreach (Touch tmp in Input.touches)
        {
            // Touch 시작 위치 설정
            if(tmp.phase ==  TouchPhase.Began)
            {
                touchStart = tmp.position;
            }

            // Touch Move - Touch 끝 위치 설정
            if(tmp.phase == TouchPhase.Moved)
            {
                Vector3 touchEnd = tmp.position;

                // Jump - 아래에서 위로 드래그 했는가?
                if(isGround && canJump && touchEnd.y - touchStart.y > 100)
                {
                    StartCoroutine("JumpHuman");
                }

                // Turn Left - 왼쪽으로 드래그 했는가?
                if (canTurn && touchEnd.x - touchStart.x < -100)
                {
                    RotateHuman("LEFT");
                }

                // Turn Right - 오른쪽으로 드래그 했는가?
                if (canTurn && touchEnd.x - touchStart.x > 100)
                {
                    RotateHuman("RIGHT");
                }
            }
        }
        
    }

    // ==============
    // 키보드 조사
    // ==============
    void CheckKeyboard()
    {
        float key = Input.GetAxis("Horizontal");

        // 좌우 이동 방향 설정
        if (key < 0 && canLeft && isGround)
            dirX = -1;

        if (key > 0 && canRight && isGround)
            dirX = 1;

        // Jump
        if (isGround && canJump && Input.GetKeyDown(KeyCode.Space))
        {
            StartCoroutine("JumpHuman");
        }

        // Turn
        if(canTurn)
        {
            if (Input.GetKeyDown(KeyCode.Q))
                RotateHuman("LEFT");
            if (Input.GetKeyDown(KeyCode.E))
                RotateHuman("RIGHT");
            
        }
    }

    // ====================
    // Jump
    // ====================
    IEnumerator JumpHuman ()
    {
        canJump = false;
        GetComponent<Rigidbody>().AddForce(Vector3.up * jumpPower);
        GetComponent<Animation>().Play("jump_pose");
            
        yield return new WaitForSeconds(1);
        GetComponent<Animation>().Play("run");
        canJump = true;
    }

    // Rotate
    void RotateHuman(string sDir)
    {
        canTurn = false;

        // 현재의 회전각 구하기
        Vector3 rot = transform.eulerAngles;

        switch(sDir)
        {
            case "LEFT":
                rot.y -= 90;
                break;
            case "RIGHT":
                rot.y += 90;
                break;
        }

        // 회전각 설정
        transform.eulerAngles = rot;

        // 주인공 방향으로 다리 만들기
        manager.SendMessage("MakeBridge", sDir, SendMessageOptions.DontRequireReceiver);
    }

    // ===============
    // 충돌 - DeadZone
    // ===============
    void OnCollisionEnter(Collision coll)
    {
        if(coll.transform.tag == "DEAD")
        {
            isDead = true;
            GetComponent<Animation>().Play("idle");
        }
    }

    // ==================
    // 충돌 기작 - 기타
    // ==================
    void OnTriggerEnter(Collider coll)
    {
        switch (coll.transform.tag)
        {
            case "TURN":
                canTurn = true;
                break;
            case "COIN":
                score += 1000;
                Destroy(coll.gameObject);
                break;
        }
    }

    // =============
    // 충돌 끝
    // =============
    void OnTriggerExit(Collider coll)
    {
        if(coll.tag == "TURN")
        {
            canTurn = false;
        }
    }

    // =================
    // OnGUI
    // =================
    void OnGUI()
    {
        GUI.skin = skin;

        string str = "<size=20><Color=#ffffff>Score : ##</Color></size>";
            GUI.Label(new Rect(1, 10, 300, 80), str.Replace("##", "" + (int)score));

        if (!isDead)
            return;
        GetComponent<Animation>().Play("idle");

        int w = Screen.width / 2;
        int h = Screen.height / 2;

        if (GUI.Button(new Rect(w - 60, h - 50, 120, 50), "Play Game"))
        {
            SceneManager.LoadScene("MainGame");
        }

        if (GUI.Button(new Rect(w - 60, h + 50, 120, 50), "Quit Game"))
        {
            Application.Quit();
        }

    }
}
