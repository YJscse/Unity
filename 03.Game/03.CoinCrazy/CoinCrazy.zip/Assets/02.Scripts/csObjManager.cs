﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class csObjManager : MonoBehaviour {

    public GameObject coin;
    public GameObject spikeBall;
    public float spawnTime = 2.0f;

    float deltaSpawnTime = 0.0f;
    float hideTime = 0.0f;

    // Use this for initialization
    void Start () {
   
    }

    // Update is called once per frame
    void Update()
    {
        int rand = Random.Range(-5, 5);

        deltaSpawnTime += Time.deltaTime;
        if(deltaSpawnTime > spawnTime && rand < 0)
        {
            deltaSpawnTime = 0.0f;

            GameObject obj = Instantiate(coin) as GameObject;
            
            int x = Random.Range(-10, 10);
            int z = Random.Range(-10, 10);
            obj.transform.position = new Vector3(x, 2.5f, z);

            Destroy(obj, 3.0f);

        }
        else if(deltaSpawnTime > spawnTime && rand > 0)
        {
            deltaSpawnTime = 0.0f;

            GameObject obj = Instantiate(spikeBall) as GameObject;

            int x = Random.Range(-10, 10);
            int z = Random.Range(-10, 10);
            obj.transform.position = new Vector3(x, 2.5f, z);

            Destroy(obj, 4.0f);
        }

   
    }

}

