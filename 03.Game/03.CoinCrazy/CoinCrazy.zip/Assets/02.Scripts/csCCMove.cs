﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class csCCMove : MonoBehaviour {

    public float walkSpeed = 2.0f;
    private Vector3 velocity;
    private Vector3 moveTo;

    public AudioClip jumpClip;

    CharacterController controller;
    Vector3 moveDirection;

    float jumpSpeed = 10.0f;        // jump speed
    float gravity = 20.0f;          // gravity

    // Use this for initialization
    void Start () {
        controller = GetComponent<CharacterController>();
        GetComponent<Animation>()["Walk"].speed = 1.5f;
    }



    // Update is called once per frame
    void Update()
    {
        if (controller.isGrounded)
        {
            if (moveTo.magnitude == 0)
            {
                // dicide speed by key input
                velocity = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));
                velocity *= walkSpeed;

                // Jump
                if (Input.GetButtonDown("Jump"))
                {
                    GetComponent<Animation>().Play("Jump");
                    velocity.y = jumpSpeed;
                    AudioManager.Instance().PlaySfx(jumpClip);
                }
                else if (velocity.magnitude > 0.5)
                {
                    GetComponent<Animation>().CrossFade("Walk", 0.1f);
                    transform.LookAt(transform.position + velocity);
                }
                else
                {
                    GetComponent<Animation>().CrossFade("Idle", 0.1f);
                }
            }

        }
        velocity.y -= gravity * Time.deltaTime;

        controller.Move(velocity * Time.deltaTime);
    }
}
