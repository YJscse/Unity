﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class csFindPlayer : MonoBehaviour {

    Transform target;

    public float power = 20.0f;

    public float idleStateMaxTime = 2.0f;
    float stateTime = 0.0f;

    public GameObject coin = null;
    public GameObject spikeBall = null;

    // public AudioClip clip;

    int i = 0;
    PlayerState playerState;
    
    void Awake()
    {
 
    }

    // Use this for initialization
    void Start () {

        target = GameObject.Find("GenericMan").transform;
        playerState = target.GetComponent<PlayerState>();

    }
	
	// Update is called once per frame
	void Update () {

        stateTime += Time.deltaTime;    
        if (stateTime > idleStateMaxTime)
        {
            stateTime = 0.0f;
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        int collisionLayer = collision.gameObject.layer;

        if (playerState.isDead == false)
        {
            if (collisionLayer == LayerMask.NameToLayer("Ground") && i == 0)
            {

                Vector3 A = new Vector3(target.position.x, 0.5f, target.position.z);

                Vector3 B = A - transform.position;

                Vector3 C = B * power;

                coin.GetComponent<Rigidbody>().AddForce(C);
                spikeBall.GetComponent<Rigidbody>().AddForce(C);
            
                i = 1;
            }
            else if(collisionLayer == LayerMask.NameToLayer("Player"))
            {
                // Coin 과 Spike가 Player라는 Layer와 부딪히면 Coin과 Spike를 없앤다.
                Destroy(gameObject);
            }
        }
    }

}
