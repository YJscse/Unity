﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerState : MonoBehaviour {

    private int hp = 100;
    public bool isDead = false;

    public int score = 10;
    public float power = 20.0f;

    public GameObject deathParticle = null;
    public GameObject coinParticle = null;
    public GameObject spikeParticle = null;
    public GameObject coin = null;
    public GameObject spikeBall = null;

    public GameObject hit;
    public Material red;
    public Material blue;

    public GUISkin Sample;

    public AudioClip deathClip;
    public AudioClip damageClip;
    public AudioClip coinClip;

    void OnGUI()
    {
        Rect rect = new Rect(0, 0, 200, 25);

        GUI.skin = Sample;
        GUI.Label(rect, "My Health : " + hp, "game");
        
        int myScore = ScoreManager.Instance().myScore;

        rect.x = Screen.width - 250;
       

        GUI.Label(rect, "Score : " + myScore, "game");
        
        if (isDead)
        {
            rect.x = Screen.width / 2;
            rect.y = Screen.height / 2;
            GUI.Label(rect, "Game Over", "gameOver");
            StartCoroutine(gameOver());
        }
    }
    
    public void DamageByEnemy()
    {
        if (isDead)
            return;

        hp = hp - 10;
                
        if(hp <= 0)
        {
            isDead = true;
            GameObject particleObj = Instantiate(deathParticle) as GameObject;
            particleObj.transform.position = transform.position;
            AudioManager.Instance().PlaySfx(deathClip);
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Coin")
        {       
            ScoreManager.Instance().myScore += score;
            GameObject particleObj = Instantiate(coinParticle) as GameObject;
            particleObj.transform.position = transform.position;

            AudioManager.Instance().PlaySfx(coinClip);
        }
        else if (collision.gameObject.tag == "SpikeBall")
        {
            hit.GetComponent<Renderer>().material = red;
            StartCoroutine("hitHit");

            DamageByEnemy();
            GameObject particleObj = Instantiate(spikeParticle) as GameObject;
            particleObj.transform.position = transform.position;

            AudioManager.Instance().PlaySfx(damageClip);
        }
    }
    IEnumerator gameOver()
    {
        yield return new WaitForSeconds(3.0f);
        SceneManager.LoadScene("Title");
    }

    IEnumerator hitHit()
    {
        yield return new WaitForSeconds(0.5f);
        hit.GetComponent<Renderer>().material =blue;
    }
}
