﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireManager : MonoBehaviour {

    public Transform cameraTransform;
    public GameObject fireObject;
    public Transform firePoint;

    public float power = 20.0f;

    PlayerState playerHealth = null;

    void Start()
    {
        playerHealth = GetComponent<PlayerState>();
    }

    // Update is called once per frame
    void Update () {

        if (PauseScript.gamePause == true)
            return;

        if (playerHealth.isDead)
            return;

        if (Input.GetButtonDown("Fire1"))
        {
            GameObject obj = Instantiate(fireObject) as GameObject;

            obj.transform.position = firePoint.transform.position;
            obj.GetComponent<Rigidbody>().velocity = cameraTransform.forward * power;
        }
	}
}
