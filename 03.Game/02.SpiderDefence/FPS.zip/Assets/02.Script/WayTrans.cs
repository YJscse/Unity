﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WayTrans : MonoBehaviour {


    public float sensitivity = 1.0f;
    public float rotationX;
    public float rotationY;

    Vector3 zeroPoint;
    Vector3 currentPoint;

    
    void Update()
    {
        foreach (Touch touch in Input.touches)
        {
          
            if (Input.touchCount > 0 && touch.position.y >= Screen.height / 2)
            {
                Debug.Log("aaa");
                if (Input.GetTouch(0).phase == TouchPhase.Began)
                {
                    //초기 터치 지점
                    zeroPoint = Input.GetTouch(0).position;

                }
                else if (Input.GetTouch(0).phase == TouchPhase.Moved)
                {
                    //현재 터치 지점
                    currentPoint = Input.GetTouch(0).position;

                    //변화량 저장
                    float deltaX = currentPoint.x - zeroPoint.x;
                    float deltaY = currentPoint.y - zeroPoint.y;

                    if (Mathf.Abs(deltaX) > Mathf.Abs(deltaY))
                    {

                        rotationY += deltaX * sensitivity * Time.deltaTime / 2;
                        // x축으로 이동상태
                        if (deltaX > 0)
                        {
                            //if (rotationX > 20.0f)
                            //    rotationX = 20.0f;
                            Debug.Log("우측으로 당김");
                        }
                        else if (deltaX < 0)
                        {
                            //if (rotationX < -30.0f)
                            //    rotationX = -30.0f;
                            Debug.Log("좌측으로 당김");
                        }
                    }

                    else if (Mathf.Abs(deltaX) < Mathf.Abs(deltaY))
                    {

                        //rotationX += deltaX * sensitivity * Time.deltaTime;
                        //y축으로 이동상태
                        if (deltaY > 0)
                        {
                            if (rotationY > 45.0f)
                                rotationY = 45.0f;
                            Debug.Log("위쪽으로 당김");
                        }
                        else if (deltaY < 0)
                        {
                            if (rotationY < -20.0f)
                                rotationY = -20.0f;
                            Debug.Log("아래쪽으로 당김");
                        }
                    }

                    transform.eulerAngles = new Vector3(-rotationX, rotationY, 0.0f);
                }


            }
        }
    }


}
