﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerState : MonoBehaviour {

    private int hp = 5;
    public bool isDead = false;

    void OnGUI()
    {
        float x = Screen.width / 2.0f - 100;

        Rect rect = new Rect(x, 10, 200, 25);

        if (isDead == false)
        {
            GUI.Box(rect, "My Health : " + hp);

            int myScore = ScoreManager.Instance().myScore;
            int bestScore = ScoreManager.Instance().bestScore;

            rect.y += 30;
            rect.height = 40;

            GUI.Box(rect, "Score : " + myScore + "\n" +
                    "Best Score : " + bestScore); 
        }
        else
        {
            GUI.Box(rect, "Game Over");
            StartCoroutine(gameOver());
        }
    }

    CameraShake cameraShake = null;

    void Start()
    {
        cameraShake = GetComponentInChildren<CameraShake>();
    }

    public void DamageByEnemy()
    {
        if (isDead)
            return;

        --hp;

        cameraShake.PlayCameraShake();
        
        if(hp <= 0)
        {
            isDead = true;
        }
    }

    IEnumerator gameOver()
    {
        yield return new WaitForSeconds(3.0f);
        SceneManager.LoadScene("Title");
    }
}
