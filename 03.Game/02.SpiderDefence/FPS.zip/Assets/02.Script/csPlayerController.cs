﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.CrossPlatformInput;

public class csPlayerController : MonoBehaviour {

    public Transform cameraTransform;
    public GameObject fireObject;
    public Transform firePoint;

    public float moveSpeed = 10.0f;
    public float jumpSpeed = 10.0f;
    public float gravity = 20.0f;
    public float power = 20.0f;

    PlayerState playerHealth = null;

    private Vector3 velocity;
    
    CharacterController controller = null;

	// Use this for initialization
	void Start () {

        // rapid walk
        controller = GetComponent<CharacterController>();
        playerHealth = GetComponent<PlayerState>();
    }

    // Update is called once per frame
    void Update() {
        

        if (PauseScript.gamePause == true)
            return;

        float y = transform.position.y;
        if (y < 0)
        {
            gameObject.transform.position = new Vector3(0f, 40f, 0f);
        }

        if (playerHealth.isDead)
           return;

        if (controller.isGrounded)
        {
            // decide speed by key input
            velocity = new Vector3(CrossPlatformInputManager.GetAxis("Horizontal"),
                                   0,
                                   CrossPlatformInputManager.GetAxis("Vertical"));
            velocity = cameraTransform.TransformDirection(velocity);

            velocity *= moveSpeed;

            // Jump
            if (CrossPlatformInputManager.GetButtonDown("Jump"))
            {
                velocity.y = jumpSpeed;
            }
        }

        if(CrossPlatformInputManager.GetButtonDown("Fire1"))
        {
            GameObject obj = Instantiate(fireObject) as GameObject;

            obj.transform.position = firePoint.transform.position;
            obj.GetComponent<Rigidbody>().velocity = cameraTransform.forward * power;
        }


        // add speed (gravity)
        velocity.y -= gravity * Time.deltaTime;

        // move character controller
        controller.Move(velocity * Time.deltaTime);
    }

   
}
