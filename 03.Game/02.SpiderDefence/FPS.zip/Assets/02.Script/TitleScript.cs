﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TitleScript : MonoBehaviour {

    public Texture2D playTexture;

    void OnGUI()
    {
        float x = Screen.width / 2.0f - 100;
        float y = Screen.height / 2.0f + 60;

        Rect rect = new Rect(x, y, 200, 70);
        if(GUI.Button(rect, playTexture))
        {
          
            SceneManager.LoadScene("Game");
        }
    }
}
