﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class csMainScript : MonoBehaviour {

    GameObject box; // 코드로 게임오브젝트를 선언
    string sStatus = "";

	// Use this for initialization
	void Start () {

        box = GameObject.Find("BattleShip"); // 게임오브젝트중에서 BattleShip의 이름으로된걸 Find(찾는다)
	}

    void OnGUI()
    {
       if(GUI.RepeatButton(new Rect(10, 240, 50, 30), " < "))
        {
            sStatus = "왼쪽으로 이동합니다";

            box.transform.Translate(Vector3.left);
        }

        if (GUI.RepeatButton(new Rect(70, 240, 50, 30), " > ")) // RepeatButton 쭉누르는것 마치 touchMove 같은것
        {
            sStatus = "오른쪽으로 이동합니다";

            box.transform.Translate(Vector3.right);
        }

        if (GUI.Button(new Rect(400, 240, 50, 30), " Fire "))
        {
            sStatus = "총알이 발사됩니다.";

            GameObject bullet = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            // bullet.transform.position = new Vector3(0.3f, 0.3f, 0.3f);
            bullet.transform.position = box.transform.position;
            bullet.transform.localScale = new Vector3(0.3f, 0.3f, 0.3f);
            bullet.name = "bullet";
            bullet.AddComponent<csBullet>();
        }

        GUILayout.Label(sStatus);
    }
  
}
