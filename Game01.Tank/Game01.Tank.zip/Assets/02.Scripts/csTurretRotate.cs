﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class csTurretRotate : MonoBehaviour {

    public float rotSpeed = 150.0f;

    // Update is called once per frame
    void Update () {

        float lRot = Input.GetAxis("lRotate");
        float rRot = Input.GetAxis("rRotate");

        float amtRot = rotSpeed * Time.deltaTime;

        transform.Rotate(Vector3.up * rRot * amtRot);
        transform.Rotate(Vector3.up * lRot * -amtRot);
    }
}
