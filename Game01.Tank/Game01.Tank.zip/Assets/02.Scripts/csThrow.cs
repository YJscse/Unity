﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class csThrow : MonoBehaviour {

    float power = 3000.0f;

    void Start()
    {
        GetComponent<Rigidbody>().AddForce(transform.forward * power);   // AddForce ← 가만있는 야구공을 야구배트로 치는것같이 힘이 작용       
    }
    // If you want to apply a force over several frames
    // you should apply it inside FixedUpdate instead of Update
    void FixedUpdate()
    {
       
        if(this.transform.position.y < 0.51f)
        {
            Destroy(this.gameObject);
        }
    }
}
