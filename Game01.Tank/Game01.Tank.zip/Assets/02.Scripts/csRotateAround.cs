﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class csRotateAround : MonoBehaviour {

    Transform obj = null;

    // Use this for initialization
    void Start()
    {

        // 찾기
        obj = GameObject.Find("pBody").transform;
    }

    // Update is called once per frame
    void Update()
    {
        // 주변 돌기 1
         transform.RotateAround(Vector3.zero, Vector3.up, 20 * Time.deltaTime);

        // 주변 돌기 2
        //transform.RotateAround(obj.position, Vector3.up, 20 * Time.deltaTime);

        transform.LookAt(obj);
    }
}
