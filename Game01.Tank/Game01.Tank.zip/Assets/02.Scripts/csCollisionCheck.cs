﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class csCollisionCheck : MonoBehaviour {

    public AudioClip clip;
    public Transform boom;

    public GameObject myParticle;
    public GameObject cannon;

    void OnCollisionEnter(Collision collision)
    {
        AudioSource.PlayClipAtPoint(clip, boom.position);
        Debug.Log("OnCollisionEnter");
        Destroy(this.gameObject);
        DoMyParticle();

    }

    void OnTriggerEnter(Collider other)
    {
        AudioSource.PlayClipAtPoint(clip, boom.position);
        Debug.Log("OnTriggerEnter");
        Destroy(this.gameObject);
        DoMyParticle();
    }

    void DoMyParticle()
    {
        GameObject particleObj = Instantiate(myParticle) as GameObject;
        particleObj.transform.position = boom.position;

        Destroy(particleObj, 1.0f);

        Debug.Log("aaaaaaaaaaaaaaaaa");
    }
}
