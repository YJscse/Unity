﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class csBullet : MonoBehaviour {

    public Transform firePos;
    public GameObject cannon;
    public AudioClip clip;
   
    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonDown("Fire1"))
        {
            Instantiate(cannon, firePos.position, firePos.rotation);
            AudioSource.PlayClipAtPoint(clip, firePos.position);
        }
    }
}
