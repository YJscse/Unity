﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class csSceneTrans4 : MonoBehaviour {

    // 기본적으로는 화면에는 한개의 Scene이 로드되고,
    // 다른 Scene을 다시 로드하는 방식으로 Scene을 교체한다.
    // 기존 Scene에 Scene을 추가할 수도 있는데, 이걸을 Additive Loading이라고 한다.
    // 만남씬 > 연애씬 > 키스씬 > 싸움씬 > 화해씬... 이렇게 씬이 교체된다고 생각하면 되고,
    // Additive Scene은 삽입 씬 처럼, 예를 들면 말풍선 모양으로 상상하는 씬(?) 같은 느낌이다.

    public void AddScene()
    {
        // 새로운 씬을 현재 씬에 추가적으로 로드 (Single은 기존 씬 close)
        SceneManager.LoadScene("08-Scene4-2", LoadSceneMode.Additive);
    }

    public void RemoveScene()
    {
        // 현재 활성화된 씬을 unload해라.
        SceneManager.UnloadScene("08-Scene4-2");
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
